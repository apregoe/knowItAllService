from django.apps import AppConfig


class KnowitallapiConfig(AppConfig):
    name = 'knowItAllAPI'
