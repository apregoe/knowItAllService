from django.apps import AppConfig


class DeletepollConfig(AppConfig):
    name = 'deletePoll'
