from django.apps import AppConfig


class CreatepostConfig(AppConfig):
    name = 'createPoll'
