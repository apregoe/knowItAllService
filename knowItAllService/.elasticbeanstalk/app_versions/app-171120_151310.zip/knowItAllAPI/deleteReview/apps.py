from django.apps import AppConfig


class DeletereviewConfig(AppConfig):
    name = 'deleteReview'
