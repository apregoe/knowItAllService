from django.db import models
from ..models import UserProfile, Poll, Topic, PollChoice