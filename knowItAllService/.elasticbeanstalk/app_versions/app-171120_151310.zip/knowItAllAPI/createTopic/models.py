from django.db import models
from ..models import Topic, Category