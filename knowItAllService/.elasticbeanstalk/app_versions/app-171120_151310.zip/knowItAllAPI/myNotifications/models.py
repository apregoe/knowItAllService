from django.db import models
from ..models import UserProfile, Review, Poll