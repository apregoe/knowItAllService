from django.db import models
from ..models import UserProfile, PollChoice, Poll, Vote